def public_user(user):
    return {
        "id": user.id, "name": user.name, "customer_id": user.customer_id,
        "account_number": user.account_number, "email": user.email,
        "phone": user.phone, "language": user.language
    }

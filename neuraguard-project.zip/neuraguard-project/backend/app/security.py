from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_passcode(value: str) -> str:
    return pwd_context.hash(value)

def verify_passcode(value: str, hashed: str) -> bool:
    return pwd_context.verify(value, hashed)

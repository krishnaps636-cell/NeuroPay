from .behavior_engine import score_behavior

def detect_fraud(features: dict):
    result = score_behavior(features)
    flags = []
    if float(features.get("paste_count",0)) >= 3: flags.append("excessive_paste")
    if float(features.get("hesitation_ms",0)) > 2500: flags.append("unusual_hesitation")
    if float(features.get("pointer_speed",0)) > 2500: flags.append("unusual_pointer_speed")
    return {
        "fraud_suspected": result["risk_score"] >= 70 or len(flags) >= 2,
        "risk_score": result["risk_score"],
        "flags": flags,
        "action": "block_and_step_up" if result["risk_score"] >= 70 else "continue_monitoring"
    }

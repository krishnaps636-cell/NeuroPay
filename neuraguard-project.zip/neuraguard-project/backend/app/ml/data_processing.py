def normalize_features(features: dict) -> dict:
    defaults = {
        "typing_wpm":42, "avg_dwell_ms":105, "avg_flight_ms":82,
        "error_rate":0.03, "paste_count":0, "hesitation_ms":240,
        "pointer_speed":650, "touch_velocity":420, "session_seconds":180
    }
    return {k: float(features.get(k, v)) for k,v in defaults.items()}

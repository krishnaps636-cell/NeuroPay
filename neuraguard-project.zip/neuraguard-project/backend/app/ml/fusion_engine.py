def fuse_signals(behavior_risk, device_risk=0, network_risk=0, context_risk=0):
    score = behavior_risk*.55 + device_risk*.15 + network_risk*.15 + context_risk*.15
    return {"risk_score": round(min(100,max(0,score)),1),
            "components":{"behavior":behavior_risk,"device":device_risk,
                          "network":network_risk,"context":context_risk}}

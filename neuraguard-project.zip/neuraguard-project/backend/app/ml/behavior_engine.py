import math
from typing import Dict, Any
import numpy as np
from sklearn.ensemble import IsolationForest

FEATURES = [
    "typing_wpm", "avg_dwell_ms", "avg_flight_ms",
    "error_rate", "paste_count", "hesitation_ms",
    "pointer_speed", "touch_velocity", "session_seconds"
]

_model = IsolationForest(
    n_estimators=100,
    contamination=0.12,
    random_state=42
)
_model.fit(np.array([
    [42, 105, 82, .03, 0, 240, 650, 420, 180],
    [48, 92, 75, .04, 0, 300, 720, 460, 210],
    [36, 130, 95, .06, 0, 400, 580, 390, 240],
    [55, 88, 70, .02, 0, 180, 800, 500, 160],
    [40, 115, 90, .05, 1, 350, 630, 430, 200],
], dtype=float))

def _v(features: Dict[str, Any], name: str, default: float) -> float:
    try:
        return float(features.get(name, default))
    except (TypeError, ValueError):
        return default

def score_behavior(features: Dict[str, Any]) -> Dict[str, Any]:
    vector = np.array([[
        _v(features, "typing_wpm", 42),
        _v(features, "avg_dwell_ms", 105),
        _v(features, "avg_flight_ms", 82),
        _v(features, "error_rate", .03),
        _v(features, "paste_count", 0),
        _v(features, "hesitation_ms", 240),
        _v(features, "pointer_speed", 650),
        _v(features, "touch_velocity", 420),
        _v(features, "session_seconds", 180),
    ]])
    prediction = int(_model.predict(vector)[0])
    raw = float(_model.decision_function(vector)[0])

    risk = 35 + max(-25, min(55, -raw * 100))
    if _v(features, "paste_count", 0) >= 3:
        risk += 12
    if _v(features, "hesitation_ms", 0) > 2500:
        risk += 10
    if _v(features, "error_rate", 0) > .25:
        risk += 8
    if _v(features, "typing_wpm", 42) < 12:
        risk += 8
    if _v(features, "pointer_speed", 650) > 2500:
        risk += 8

    risk = round(max(0, min(100, risk)), 1)
    label = "normal" if risk < 45 else "review" if risk < 70 else "high-risk"
    return {
        "risk_score": risk,
        "label": label,
        "model_prediction": "inlier" if prediction == 1 else "anomaly",
        "explanation": (
            "Behavior is close to the learned interaction baseline."
            if label == "normal" else
            "Some interaction signals differ from the baseline; step-up verification is recommended."
            if label == "review" else
            "Multiple signals look unusual; the demo recommends blocking access until verification."
        )
    }

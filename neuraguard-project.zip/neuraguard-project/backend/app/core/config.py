import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    APP_NAME = "NeuraGuard API"
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./neuraguard.db")
    REDIS_URL = os.getenv("REDIS_URL", "")
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")

settings = Settings()

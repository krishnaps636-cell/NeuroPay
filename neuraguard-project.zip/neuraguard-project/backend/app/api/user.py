from fastapi import APIRouter
router = APIRouter(prefix="/api/user", tags=["user"])

@router.get("/status")
def status():
    return {"service":"user","status":"ready"}

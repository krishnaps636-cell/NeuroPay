from fastapi import APIRouter
from pydantic import BaseModel
from app.ml.fraud_detector import detect_fraud
from app.ml.fusion_engine import fuse_signals

router = APIRouter(prefix="/api/fraud", tags=["fraud"])

class FraudRequest(BaseModel):
    features: dict
    device_risk: float = 0
    network_risk: float = 0
    context_risk: float = 0

@router.post("/analyze")
def analyze(body: FraudRequest):
    fraud = detect_fraud(body.features)
    return {**fraud, "fusion": fuse_signals(
        fraud["risk_score"], body.device_risk, body.network_risk, body.context_risk
    )}

from fastapi import APIRouter
router = APIRouter(prefix="/api/auth", tags=["authentication"])

@router.get("/status")
def status():
    return {"service":"authentication","status":"ready"}

from pydantic import BaseModel, Field
from typing import Any, Dict, Optional

class SignupRequest(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str
    phone: str
    passcode: str = Field(min_length=4, max_length=32)
    language: str = "en"

class LoginRequest(BaseModel):
    customer_id: str
    account_number: str
    passcode: str
    behavior_score: float = 50
    face_verified: bool = False
    behavior_verified: bool = False
    captcha_passed: bool = True

class BehaviorRequest(BaseModel):
    session_id: str
    event_type: str
    features: Dict[str, Any]
    user_id: Optional[int] = None

class FacePresenceRequest(BaseModel):
    image_base64: str
    session_id: str
    user_id: Optional[int] = None

class AIActionRequest(BaseModel):
    action: str
    risk_score: float
    context: Dict[str, Any] = {}

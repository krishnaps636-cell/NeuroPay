import base64
import os
import uuid
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import cv2
import numpy as np

from .database import SessionLocal, init_db
from .models import User, BehaviorEvent, SecurityEvent
from .schemas import SignupRequest, LoginRequest, BehaviorRequest, FacePresenceRequest, AIActionRequest
from .security import hash_passcode, verify_passcode
from .ml_engine import score_behavior

app = FastAPI(title="NeuraGuard API", version="1.0.0")

origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()

def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "NeuraGuard API"}

@app.post("/api/auth/signup")
def signup(payload: SignupRequest, session: Session = Depends(db)):
    existing = session.query(User).filter(
        (User.customer_id == payload.email) | (User.email == payload.email)
    ).first()
    if existing:
        raise HTTPException(409, "An account with this email already exists.")

    customer_id = "NG" + uuid.uuid4().hex[:8].upper()
    account = "91" + str(np.random.randint(10**9, 10**10 - 1))
    user = User(
        customer_id=customer_id,
        account_number=account,
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
        passcode_hash=hash_passcode(payload.passcode),
        language=payload.language,
    )
    session.add(user)
    session.commit()
    session.refresh(user)
    return {
        "message": "Account created",
        "customer_id": user.customer_id,
        "account_number": user.account_number,
        "user_id": user.id,
    }

@app.post("/api/auth/behavior")
def behavior(payload: BehaviorRequest, session: Session = Depends(db)):
    result = score_behavior(payload.features)
    event = BehaviorEvent(
        user_id=payload.user_id,
        session_id=payload.session_id,
        event_type=payload.event_type,
        features=payload.features,
        risk_score=result["risk_score"],
    )
    session.add(event)

    if result["risk_score"] >= 70:
        session.add(SecurityEvent(
            user_id=payload.user_id,
            event_type="BEHAVIOR_ANOMALY",
            severity="high",
            message="Unusual interaction pattern detected. Step-up verification is required.",
        ))
    session.commit()
    return result

@app.post("/api/auth/face-presence")
def face_presence(payload: FacePresenceRequest, session: Session = Depends(db)):
    try:
        raw = payload.image_base64.split(",", 1)[-1]
        data = base64.b64decode(raw)
        arr = np.frombuffer(data, np.uint8)
        image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError("Invalid image")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        faces = cascade.detectMultiScale(gray, 1.1, 5)
        verified = len(faces) >= 1
    except Exception:
        verified = False

    if not verified:
        raise HTTPException(422, "No clear face was detected. Try again in good lighting.")

    return {
        "verified": True,
        "message": "Face presence detected. This demo does not identify or store your face."
    }

@app.post("/api/auth/login")
def login(payload: LoginRequest, session: Session = Depends(db)):
    user = session.query(User).filter(User.customer_id == payload.customer_id).first()
    if not user or not verify_passcode(payload.passcode, user.passcode_hash):
        raise HTTPException(401, "Customer ID, account number, or passcode is incorrect.")

    if user.account_number != payload.account_number:
        raise HTTPException(401, "Account number does not match this session.")

    if not payload.captcha_passed:
        raise HTTPException(403, "Automated behavior check failed.")

    if not payload.behavior_verified or not payload.face_verified:
        session.add(SecurityEvent(
            user_id=user.id,
            event_type="VERIFICATION_REQUIRED",
            severity="medium",
            message="Login requires all configured verification steps.",
        ))
        session.commit()
        raise HTTPException(403, "Complete behavioral and face verification before entering the account.")

    if payload.behavior_score >= 70:
        session.add(SecurityEvent(
            user_id=user.id,
            event_type="HIGH_RISK_LOGIN",
            severity="high",
            message="Login blocked because the behavioral risk score is high.",
        ))
        session.commit()
        raise HTTPException(403, "Login blocked. A high-risk interaction pattern was detected.")

    user.last_login = datetime.now(timezone.utc)
    session.commit()
    return {
        "message": "Login verified",
        "user": {
            "id": user.id,
            "name": user.name,
            "customer_id": user.customer_id,
            "account_number": user.account_number,
            "email": user.email,
        },
        "risk_score": payload.behavior_score,
        "session_token": uuid.uuid4().hex,
    }

@app.get("/api/dashboard")
def dashboard(session: Session = Depends(db)):
    user = session.query(User).first()
    events = session.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(6).all()
    if not user:
        return {
            "balance": 0,
            "user": None,
            "security_events": [],
        }
    return {
        "balance": 68420.50,
        "user": {
            "id": user.id,
            "name": user.name,
            "customer_id": user.customer_id,
            "account_number": user.account_number,
            "email": user.email,
        },
        "security_events": [
            {
                "type": e.event_type,
                "severity": e.severity,
                "message": e.message,
                "created_at": e.created_at.isoformat(),
            } for e in events
        ],
    }

@app.get("/api/security/events")
def security_events(session: Session = Depends(db)):
    events = session.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(20).all()
    return [{
        "type": e.event_type,
        "severity": e.severity,
        "message": e.message,
        "resolved": e.resolved,
        "created_at": e.created_at.isoformat(),
    } for e in events]

@app.post("/api/ai/action")
def ai_action(payload: AIActionRequest):
    risk = float(payload.risk_score)
    action = payload.action.lower()
    if risk >= 70:
        recommendation = "Block the sensitive action and request step-up verification."
    elif risk >= 45:
        recommendation = "Allow low-risk browsing but request an additional verification before payment."
    else:
        recommendation = "Continue monitoring and allow normal navigation."
    return {
        "mode": "NeuraGuard AI",
        "action": action,
        "risk_score": risk,
        "recommendation": recommendation,
        "note": "Demo rule engine. A production AI agent needs governance, evaluation, and explicit action permissions.",
    }

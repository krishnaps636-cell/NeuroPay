from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON
from .database import Base

def now():
    return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    customer_id = Column(String(64), unique=True, nullable=False, index=True)
    account_number = Column(String(64), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    email = Column(String(180), nullable=False)
    phone = Column(String(40), nullable=False)
    passcode_hash = Column(String(255), nullable=False)
    language = Column(String(20), default="en")
    created_at = Column(DateTime(timezone=True), default=now)
    last_login = Column(DateTime(timezone=True), nullable=True)

class BehaviorEvent(Base):
    __tablename__ = "behavior_events"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=True)
    session_id = Column(String(100), index=True)
    event_type = Column(String(60), nullable=False)
    features = Column(JSON, nullable=False)
    risk_score = Column(Float, default=0)
    created_at = Column(DateTime(timezone=True), default=now)

class SecurityEvent(Base):
    __tablename__ = "security_events"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=True)
    event_type = Column(String(80), nullable=False)
    severity = Column(String(20), nullable=False)
    message = Column(String(500), nullable=False)
    resolved = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=now)

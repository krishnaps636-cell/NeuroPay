# NeuraGuard Project

Your invisible behavioural fingerprint is now your most powerful password.

## Structure

- backend/app/api — FastAPI endpoints
- backend/app/core — configuration
- backend/app/db — database models/session
- backend/app/ml — behavioral/fraud/fusion pipeline
- backend/app/services — business logic
- frontend/src/components — reusable UI
- frontend/src/pages — page-level UI
- frontend/src/contexts — React contexts
- frontend/src/hooks — gesture/behavior capture
- frontend/src/services — API calls
- frontend/src/utils/i18n.js — five-language UI strings
- data — sample data
- docs — architecture/security documentation

## Run backend

cd backend
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py -m uvicorn app.main:app --reload --port 8000

## Run frontend

cd frontend
npm install
npm run dev

The exact frontend command depends on the package setup included in the archive.

This is a project/demo implementation, not a production banking system.

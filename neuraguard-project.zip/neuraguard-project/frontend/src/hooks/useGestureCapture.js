import {useEffect, useRef} from "react";

export default function useGestureCapture(){
  const ref = useRef({pointer:0,touch:0});
  useEffect(()=>{
    const p=()=>ref.current.pointer++;
    const t=()=>ref.current.touch++;
    window.addEventListener("pointermove",p,{passive:true});
    window.addEventListener("touchmove",t,{passive:true});
    return ()=>{window.removeEventListener("pointermove",p);window.removeEventListener("touchmove",t)};
  },[]);
  return ref;
}

const API = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000/api";

async function request(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

export const api = {
  health: () => request("/health"),
  signup: (body) => request("/auth/signup", { method: "POST", body: JSON.stringify(body) }),
  login: (body) => request("/auth/login", { method: "POST", body: JSON.stringify(body) }),
  behavior: (body) => request("/auth/behavior", { method: "POST", body: JSON.stringify(body) }),
  facePresence: (body) => request("/auth/face-presence", { method: "POST", body: JSON.stringify(body) }),
  dashboard: () => request("/dashboard"),
  ai: (body) => request("/ai/action", { method: "POST", body: JSON.stringify(body) }),
};

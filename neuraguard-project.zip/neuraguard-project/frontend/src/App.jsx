import { useState } from "react";
import Sidebar from "./components/Sidebar";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import AIPage from "./pages/AIPage";
import FaceVerification from "./components/FaceVerification";

export default function App() {
  const [user,setUser]=useState(null);
  const [page,setPage]=useState("dashboard");
  const [lang,setLang]=useState("en");
  const [risk,setRisk]=useState(22);
  const [face,setFace]=useState(false);

  if (!user) return <Auth onLogin={(u,token,r)=>{sessionStorage.setItem("ng_session",token);setRisk(r);setUser(u);}}/>;

  return <div className="app-shell">
    <Sidebar lang={lang} setLang={setLang} page={page} setPage={setPage} onLogout={()=>{sessionStorage.clear();setUser(null)}}/>
    <main className="main">
      {page==="dashboard" && <Dashboard user={user} risk={risk} setRisk={setRisk}/>}
      {page==="behavior" && <div className="content"><div className="topbar"><div><span className="eyebrow">CONTINUOUS SECURITY</span><h1>Behaviour engine</h1></div></div><Dashboard user={user} risk={risk} setRisk={setRisk}/></div>}
      {page==="verify" && <div className="content"><div className="topbar"><div><span className="eyebrow">STEP-UP VERIFICATION</span><h1>Verify your presence</h1></div></div><FaceVerification onVerified={setFace}/><div className="verify-state">{face?"✓ Verification complete":"Verification required before sensitive actions"}</div></div>}
      {page==="ai" && <AIPage risk={risk}/>}
    </main>
  </div>
}

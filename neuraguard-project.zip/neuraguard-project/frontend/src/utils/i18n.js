export const languages = ["en","hi","kn","ta","te"];
export const translations = {
  en:{home:"Home",features:"Features",login:"Sign in",signup:"Get started"},
  hi:{home:"होम",features:"फीचर्स",login:"साइन इन",signup:"शुरू करें"},
  kn:{home:"ಮುಖಪುಟ",features:"ವೈಶಿಷ್ಟ್ಯಗಳು",login:"ಸೈನ್ ಇನ್",signup:"ಪ್ರಾರಂಭಿಸಿ"},
  ta:{home:"முகப்பு",features:"அம்சங்கள்",login:"உள்நுழை",signup:"தொடங்கவும்"},
  te:{home:"హోమ్",features:"ఫీచర్లు",login:"సైన్ ఇన్",signup:"ప్రారంభించండి"}
};

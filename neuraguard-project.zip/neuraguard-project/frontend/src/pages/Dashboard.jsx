import { useEffect, useState } from "react";
import { ArrowUpRight, ArrowDownLeft, CreditCard, ShieldCheck, Bell, Send, QrCode } from "lucide-react";
import { api } from "../services/api";
import BehaviorMonitor from "../components/BehaviorMonitor";

export default function Dashboard({user, risk, setRisk}) {
  const [data, setData] = useState(null);
  useEffect(()=>{ api.dashboard().then(setData).catch(()=>{}); },[]);
  return <div className="content">
    <div className="topbar"><div><span className="eyebrow">SECURE WALLET</span><h1>Good evening, {user?.name?.split(" ")[0] || "User"}</h1></div><div className="top-actions"><button className="icon-btn"><Bell/></button><div className="avatar">{(user?.name||"U")[0]}</div></div></div>
    <div className="balance-grid">
      <div className="balance-card"><div className="card-label"><span>Total balance</span><CreditCard/></div><div className="balance">₹{(data?.balance||68420.50).toLocaleString("en-IN",{minimumFractionDigits:2})}</div><div className="account-label">{user?.account_number || "•••• •••• 4218"}</div><div className="balance-actions"><button><Send/> Send</button><button><QrCode/> Pay</button><button><ArrowDownLeft/> Add</button></div></div>
      <div className="trust-card"><div className="card-label"><span>Trust status</span><ShieldCheck/></div><div className="trust-score">{Math.max(0,100-Math.round(risk))}<small>/100</small></div><p>{risk<45?"Your interaction looks familiar.":"Additional verification may be required."}</p><div className="trust-bar"><i style={{width:`${Math.max(5,100-risk)}%`}}></i></div></div>
    </div>
    <BehaviorMonitor userId={user?.id} onScore={setRisk}/>
    <div className="section-title"><h2>Recent activity</h2><button>View all</button></div>
    <div className="activity-list">
      {["UPI payment · Grocery Store","Money received · Rahul","Bill payment · Electricity"].map((x,i)=><div className="activity" key={x}><div className="activity-icon">{i===0?<ArrowUpRight/>:<ArrowDownLeft/>}</div><div><b>{x}</b><small>{i===0?"Today, 8:42 PM":"Yesterday, 6:10 PM"}</small></div><strong className={i===0?"debit":"credit"}>{i===0?"− ₹1,240":"+"+" ₹2,500"}</strong></div>)}
    </div>
  </div>
}

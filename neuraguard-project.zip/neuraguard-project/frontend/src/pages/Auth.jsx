import { useEffect, useState } from "react";
import { ShieldCheck, Keyboard, ScanFace, MousePointer2, LockKeyhole, ArrowRight } from "lucide-react";
import { api } from "../services/api";

export default function Auth({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({name:"Kishan", email:"demo@neuraguard.local", phone:"9999999999", customer_id:"", account_number:"", passcode:"1234", language:"en"});
  const [face, setFace] = useState(false);
  const [behavior, setBehavior] = useState(32);
  const [msg, setMsg] = useState("");
  const [faceRequired] = useState(true);

  useEffect(()=> {
    const onKey = e => {
      if (e.key === "Backspace") setBehavior(s=>Math.min(100,s+1));
      else if (e.key.length === 1) setBehavior(s=>Math.max(0,s-.05));
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[]);

  const submitSignup = async e => {
    e.preventDefault();
    try {
      const r = await api.signup(form);
      setMsg(`Account created. Customer ID: ${r.customer_id} · Account: ${r.account_number}`);
      setForm(f=>({...f, customer_id:r.customer_id, account_number:r.account_number}));
      setMode("login");
    } catch(e) { setMsg(e.message); }
  };

  const submitLogin = async e => {
    e.preventDefault();
    try {
      const r = await api.login({
        customer_id: form.customer_id,
        account_number: form.account_number,
        passcode: form.passcode,
        behavior_score: behavior,
        behavior_verified: true,
        face_verified: face,
        captcha_passed: true
      });
      onLogin(r.user, r.session_token, behavior);
    } catch(e) { setMsg(e.message); }
  };

  return (
    <main className="auth-page">
      <div className="auth-glow"></div>
      <div className="auth-brand"><div className="logo-mark"><ShieldCheck/></div><b>NeuraGuard</b></div>
      <div className="auth-grid">
        <section className="hero-copy">
          <span className="eyebrow">SILENT GUARD · REIMAGINED</span>
          <h1>Your behaviour becomes your password.</h1>
          <p>Your invisible behavioural fingerprint is now your most powerful password.</p>
          <div className="feature-pills">
            <span><Keyboard/> Typing rhythm</span><span><ScanFace/> Face safety check</span><span><MousePointer2/> Touch & pointer</span><span><LockKeyhole/> Continuous trust</span>
          </div>
        </section>
        <section className="auth-card">
          <div className="tabs"><button className={mode==="login"?"selected":""} onClick={()=>setMode("login")}>Sign in</button><button className={mode==="signup"?"selected":""} onClick={()=>setMode("signup")}>Create account</button></div>
          <div className="auth-heading"><h2>{mode==="login"?"Secure sign in":"Create your NeuraGuard account"}</h2><p>Every interaction adds another layer of confidence.</p></div>
          <form onSubmit={mode==="login"?submitLogin:submitSignup}>
            {mode==="signup" && <>
              <label>Full name<input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required /></label>
              <label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required /></label>
              <label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required /></label>
            </>}
            {mode==="login" && <>
              <label>Customer ID<input value={form.customer_id} onChange={e=>setForm({...form,customer_id:e.target.value})} placeholder="e.g. NG12AB34CD" required /></label>
              <label>Account number<input value={form.account_number} onChange={e=>setForm({...form,account_number:e.target.value})} required /></label>
            </>}
            <label>Passcode<input type="password" value={form.passcode} onChange={e=>setForm({...form,passcode:e.target.value})} required /></label>
            {mode==="login" && <div className="verification-strip"><div><span className="check">✓</span><b>Behavioural check active</b><small>Live typing and interaction analysis</small></div><strong>{Math.round(behavior)}/100</strong></div>}
            {mode==="login" && <div className="mini-face"><span><ScanFace/> Face verification required</span><button type="button" onClick={()=>setFace(!face)}>{face?"Verified":"Mark verified"}</button></div>}
            <button className="primary-btn wide" type="submit">{mode==="login"?"Enter securely":"Create protected account"} <ArrowRight size={18}/></button>
          </form>
          {msg && <div className="auth-message">{msg}</div>}
          <p className="consent">By continuing, this demo records interaction signals for the security simulation. Use only with user consent.</p>
        </section>
      </div>
    </main>
  );
}

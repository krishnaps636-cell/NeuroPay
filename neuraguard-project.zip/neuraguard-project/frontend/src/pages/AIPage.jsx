import { useState } from "react";
import { Bot, Sparkles, ShieldAlert } from "lucide-react";
import { api } from "../services/api";

export default function AIPage({risk}) {
  const [result,setResult]=useState(null);
  const run = async(action) => setResult(await api.ai({action,risk_score:risk,context:{source:"dashboard"}}));
  return <div className="content">
    <div className="topbar"><div><span className="eyebrow">NEURAGUARD AI</span><h1>Security action mode</h1></div><div className="ai-badge"><Sparkles/> AI ACTIVE</div></div>
    <div className="ai-hero"><div className="ai-icon"><Bot/></div><div><h2>Let the security assistant act on context.</h2><p>It reads the demo risk score and suggests a reversible security action. Every action remains visible to you.</p></div></div>
    <div className="action-grid">
      {["Review login","Protect a payment","Explain my risk","Check recent activity"].map(a=><button onClick={()=>run(a)} key={a}><ShieldAlert/><span>{a}</span><small>Run AI analysis</small></button>)}
    </div>
    {result && <div className="ai-result"><span className="eyebrow">AI RESPONSE</span><h3>{result.recommendation}</h3><p>Risk score: <b>{result.risk_score}</b> · {result.note}</p></div>}
  </div>
}

import { useRef, useState } from "react";
import { Camera, CheckCircle2, ShieldAlert } from "lucide-react";
import { api } from "../services/api";

export default function FaceVerification({ onVerified }) {
  const video = useRef(null);
  const canvas = useRef(null);
  const [active, setActive] = useState(false);
  const [message, setMessage] = useState("Camera verification is off.");
  const [verified, setVerified] = useState(false);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({video: true, audio:false});
      video.current.srcObject = stream;
      await video.current.play();
      setActive(true);
      setMessage("Center your face and tap Verify.");
    } catch {
      setMessage("Camera permission was not granted.");
    }
  };

  const verify = async () => {
    if (!video.current || !canvas.current) return;
    const c = canvas.current;
    c.width = video.current.videoWidth || 640;
    c.height = video.current.videoHeight || 480;
    c.getContext("2d").drawImage(video.current, 0, 0, c.width, c.height);
    const image = c.toDataURL("image/jpeg", .75);
    try {
      await api.facePresence({image_base64:image, session_id:"verify-session"});
      setVerified(true);
      setMessage("Face presence verified. Demo does not identify or store your face.");
      onVerified?.(true);
    } catch (e) {
      setMessage(e.message);
      onVerified?.(false);
    }
  };

  return (
    <div className="verify-card">
      <div className="verify-title"><Camera/> <div><b>Biometric safety check</b><span>Face-presence verification</span></div></div>
      <div className="camera-box">
        <video ref={video} muted playsInline></video>
        {!active && <div className="camera-placeholder"><Camera size={36}/><span>Camera is ready</span></div>}
        {verified && <div className="verified-overlay"><CheckCircle2 size={54}/><b>Verified</b></div>}
      </div>
      <canvas ref={canvas} hidden />
      <div className="verify-actions">
        <button className="secondary-btn" onClick={start}>Enable camera</button>
        <button className="primary-btn" disabled={!active || verified} onClick={verify}>Verify face</button>
      </div>
      <p className="tiny-note"><ShieldAlert size={14}/> Demo checks for a visible face; it does not perform identity matching.</p>
      <div className="message">{message}</div>
    </div>
  );
}

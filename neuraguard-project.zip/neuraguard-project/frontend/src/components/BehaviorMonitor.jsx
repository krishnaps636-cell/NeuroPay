import { useEffect, useRef, useState } from "react";
import { api } from "../services/api";

export default function BehaviorMonitor({ userId, onScore }) {
  const [score, setScore] = useState(18);
  const [status, setStatus] = useState("Learning your interaction baseline…");
  const started = useRef(Date.now());
  const data = useRef({keys: [], flights: [], dwell: [], errors: 0, pastes: 0, hesitations: [], pointer: [], touch: []});
  const lastKey = useRef(null);

  useEffect(() => {
    const keydown = (e) => {
      const now = performance.now();
      if (lastKey.current !== null) data.current.flights.push(now - lastKey.current);
      lastKey.current = now;
      data.current.keys.push(now);
    };
    const keyup = (e) => {
      const now = performance.now();
      const key = e.key;
      if (lastKey.current !== null && key) data.current.dwell.push(Math.min(800, 70 + Math.random()*90));
    };
    const paste = () => data.current.pastes.push(Date.now());
    const pointer = (e) => {
      if (data.current.pointer.length < 150) data.current.pointer.push([e.clientX, e.clientY, performance.now()]);
    };
    const touch = (e) => {
      if (data.current.touch.length < 80 && e.touches[0]) data.current.touch.push([e.touches[0].clientX, e.touches[0].clientY, performance.now()]);
    };
    window.addEventListener("keydown", keydown);
    window.addEventListener("keyup", keyup);
    window.addEventListener("paste", paste);
    window.addEventListener("pointermove", pointer, {passive:true});
    window.addEventListener("touchmove", touch, {passive:true});
    const timer = setInterval(async () => {
      const d = data.current;
      const minutes = Math.max((Date.now()-started.current)/60000, .1);
      const wpm = Math.max(5, Math.round(d.keys.length / 5 / minutes));
      const avgDwell = d.dwell.length ? d.dwell.reduce((a,b)=>a+b,0)/d.dwell.length : 105;
      const avgFlight = d.flights.length ? d.flights.reduce((a,b)=>a+b,0)/d.flights.length : 82;
      const pointerSpeed = d.pointer.length > 3 ? Math.min(3000, 500 + d.pointer.length*3) : 650;
      const hesitation = Math.min(5000, 180 + d.pastes.length*500);
      const features = {
        typing_wpm: wpm,
        avg_dwell_ms: avgDwell,
        avg_flight_ms: avgFlight,
        error_rate: 0.03,
        paste_count: d.pastes.length,
        hesitation_ms: hesitation,
        pointer_speed: pointerSpeed,
        touch_velocity: 420,
        session_seconds: Math.round((Date.now()-started.current)/1000)
      };
      try {
        const result = await api.behavior({
          session_id: window.sessionStorage.getItem("ng_session") || "demo-session",
          event_type: "continuous",
          features,
          user_id: userId
        });
        setScore(result.risk_score);
        setStatus(result.explanation);
        onScore?.(result.risk_score);
      } catch {}
    }, 5000);
    return () => {
      window.removeEventListener("keydown", keydown);
      window.removeEventListener("keyup", keyup);
      window.removeEventListener("paste", paste);
      window.removeEventListener("pointermove", pointer);
      window.removeEventListener("touchmove", touch);
      clearInterval(timer);
    };
  }, [userId, onScore]);

  const ring = Math.max(0, Math.min(100, score));
  return (
    <div className="behavior-card">
      <div className="behavior-head"><div><span className="eyebrow">LIVE ENGINE</span><h2>Behavioural Fingerprint</h2></div><span className="live-dot">● Monitoring</span></div>
      <div className="risk-row">
        <div className="risk-ring" style={{"--score": `${ring*3.6}deg`}}><strong>{Math.round(ring)}</strong><span>risk</span></div>
        <div className="signals">
          <div><b>Typing dynamics</b><span>Flight · dwell · rhythm · correction</span></div>
          <div><b>Touch & pointer</b><span>Velocity · trajectory · gesture profile</span></div>
          <div><b>Context</b><span>Session timing · navigation · interaction sequence</span></div>
        </div>
      </div>
      <div className="status-line"><span className="pulse"></span>{status}</div>
    </div>
  );
}

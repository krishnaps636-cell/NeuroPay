import { ShieldCheck, LayoutDashboard, ScanFace, Activity, Bot, Languages, LogOut } from "lucide-react";

const labels = {
  en: { dashboard: "Dashboard", behavior: "Behavior Engine", verify: "Verification", ai: "AI Mode", logout: "Logout", language: "Language" },
  hi: { dashboard: "डैशबोर्ड", behavior: "व्यवहार इंजन", verify: "सत्यापन", ai: "AI मोड", logout: "लॉगआउट", language: "भाषा" },
  kn: { dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", behavior: "ವರ್ತನೆ ಎಂಜಿನ್", verify: "ಪರಿಶೀಲನೆ", ai: "AI ಮೋಡ್", logout: "ಲಾಗ್‌ಔಟ್", language: "ಭಾಷೆ" },
  ta: { dashboard: "டாஷ்போர்டு", behavior: "நடத்தை இயந்திரம்", verify: "சரிபார்ப்பு", ai: "AI பயன்முறை", logout: "வெளியேறு", language: "மொழி" },
  te: { dashboard: "డాష్‌బోర్డ్", behavior: "బిహేవియర్ ఇంజిన్", verify: "ధృవీకరణ", ai: "AI మోడ్", logout: "లాగ్ అవుట్", language: "భాష" }
};

export default function Sidebar({ lang, setLang, page, setPage, onLogout }) {
  const t = labels[lang] || labels.en;
  return (
    <aside className="sidebar">
      <div className="brand"><div className="logo-mark"><ShieldCheck size={23}/></div><div><b>NeuraGuard</b><small>Invisible security</small></div></div>
      <nav>
        <button className={page==="dashboard" ? "active":""} onClick={()=>setPage("dashboard")}><LayoutDashboard/> {t.dashboard}</button>
        <button className={page==="behavior" ? "active":""} onClick={()=>setPage("behavior")}><Activity/> {t.behavior}</button>
        <button className={page==="verify" ? "active":""} onClick={()=>setPage("verify")}><ScanFace/> {t.verify}</button>
        <button className={page==="ai" ? "active":""} onClick={()=>setPage("ai")}><Bot/> {t.ai}</button>
      </nav>
      <div className="side-bottom">
        <label><Languages size={16}/> {t.language}</label>
        <select value={lang} onChange={e=>setLang(e.target.value)}>
          <option value="en">English</option>
          <option value="hi">हिन्दी</option>
          <option value="kn">ಕನ್ನಡ</option>
          <option value="ta">தமிழ்</option>
          <option value="te">తెలుగు</option>
        </select>
        <button className="logout" onClick={onLogout}><LogOut/> {t.logout}</button>
      </div>
    </aside>
  );
}

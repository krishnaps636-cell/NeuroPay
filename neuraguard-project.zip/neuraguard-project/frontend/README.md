# NeuraGuard Frontend

Install dependencies with npm install and start the development server with npm run dev.
The frontend expects the FastAPI service at http://127.0.0.1:8000/api unless configured otherwise.

# NeuraGuard Architecture

React captures interaction signals and sends summarized features to FastAPI.
FastAPI connects the authentication, user and fraud APIs with SQLite/SQLAlchemy.
The ML layer contains behavioral scoring, fraud detection, preprocessing and multi-modal fusion.
Redis is optional for session/cache management.

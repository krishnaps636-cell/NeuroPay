# Security Notes

This is a demonstration project. Production financial authentication requires
professional security review, consent and privacy controls, secure sessions,
rate limiting, encryption, passkeys/WebAuthn, validated biometric verification,
ML evaluation and auditable fraud-review processes.
